package com.enums;

public enum seates {
	

}
