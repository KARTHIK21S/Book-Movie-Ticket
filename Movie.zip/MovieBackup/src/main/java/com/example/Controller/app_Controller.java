package com.example.Controller;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.example.model.seat_booking_detailes;
import com.example.model.users;
import com.example.repo.UserInterFace;
import com.example.repo.seatBookingRepo;

import jakarta.servlet.http.HttpServletRequest;

@Controller
public class app_Controller {

    @Autowired
    private UserInterFace userService;

    @Autowired
    private seatBookingRepo seatBookingService;

    @Autowired
    private seat_booking_detailes BDTLS;

    private String movieName;
    private String time;
    private String date;
    private String bookingUserName;
    private String bookingUserEmail;
    private BigInteger mobileNumber;
    
    @GetMapping("/")
    public String home() {
        return "registerform";
    }


    @PostMapping("/Register")
    @Transactional
    public String register(HttpServletRequest req) {
        String Name = req.getParameter("name");
        String mobile1 = req.getParameter("mobile");
        BigInteger mobile = new BigInteger(mobile1);
        String Email = req.getParameter("email");
        String username = req.getParameter("username");
        String password = req.getParameter("password");

        users user = new users();
        user.setName(Name);
        user.setMobile(mobile);
        user.setEmail(Email);
        user.setUserName(username);
        user.setPassword(password);

        userService.save(user);
        return "login";
    }

    @PostMapping("/login")
    public String login(HttpServletRequest req) {
        String username = req.getParameter("username");
        String password = req.getParameter("password");

        List<users> allUsers = userService.findAll();

        for (users user : allUsers) {
            if (username.equals(user.getUserName()) && password.equals(user.getPassword())) {
                return "home";
            }
        }
        return "FailLogin";
    }

    @GetMapping("/login")
    public String login() {
        return "login";
    }
    
    @GetMapping("/forgotpassword")
    public String forgotpassword() {
        return "ForgotPassword";
    }

    @PostMapping("/reset-password")
    @Transactional
    public String resetPassword(HttpServletRequest req, Model model) {
        String username = req.getParameter("username");
        String newPassword = req.getParameter("new-password");
        String confirmPassword = req.getParameter("confirm-password");

        if (!newPassword.equals(confirmPassword)) {
            model.addAttribute("error", "Passwords do not match.");
            return "ForgotPassword";
        }

        users user = userService.findByUserName(username);
        if (user == null) {
            model.addAttribute("error", "Username not found.");
            return "ForgotPassword";
        }

        user.setPassword(newPassword);
        userService.save(user);

        return "login";
    }


    @GetMapping("/privecy")
    public String privacyPolicy() {
        return "Privecy";
    }

    @GetMapping("/terms")
    public String Terms() {
        return "TermsAndConditions";
    }

    @GetMapping("/FAQ")
    public String FAQ() {
        return "FAQ";
    }

    @GetMapping("/movies")
    public String movies() {
        return "movies";
    }

    @GetMapping("/movie-details.html")
    public String movieInfo(HttpServletRequest req) {
        String movie = req.getParameter("movie");

        switch (movie) {
            case "legent":
                return "legentDTLS";
            case "naaisekar":
                return "naaisekarDTLS";
            case "merasal":
                return "merasalDTLS";
            default:
                return null;
        }
    }

    @GetMapping("/showTime")
    public String showTimes() {
        return "showTiming";
    }

    @GetMapping("/Bookings")
    public String Booking(Model m) {
        List<seat_booking_detailes> allBookings = seatBookingService.findAll();
        m.addAttribute("AllBooking", allBookings);
        return "BookingHistory";
    }

    @GetMapping("/contectUs")
    public String contactUs() {
        return "contectUs";
    }

    @GetMapping("/BookNow")
    public String BookNow() {
        return "booking";
    }

    @GetMapping("/BookingDTLS")
    public String BookingDTLS(HttpServletRequest req, Model m) {
        movieName = req.getParameter("movie");
        time = req.getParameter("showtime");
        date = req.getParameter("show-date");
        bookingUserName = req.getParameter("name");
        bookingUserEmail = req.getParameter("email");
        String bookingUserMobile = req.getParameter("phone");
        mobileNumber = new BigInteger(bookingUserMobile);

        List<seat_booking_detailes> allBookings = seatBookingService.findAll();

        // Call some utility method to get same bookings (logic assumed to exist)
        importent_Methods sa = new importent_Methods();
        List<seat_booking_detailes> ans1 = sa.getSameBookings(movieName, date, time, allBookings);

        if (ans1 != null) {
            String[] arr = new String[50];
            int a = 1;
            for (seat_booking_detailes item : ans1) {
                arr[a] = item.getSeatts();
                a++;
            }

            String MainMasilaAnswer_is = Arrays.stream(arr)
                    .filter(s -> s != null)
                    .collect(Collectors.joining(", "));

            if (MainMasilaAnswer_is != null && !MainMasilaAnswer_is.isEmpty()) {
                List<String> bookedSeatList = Arrays.asList(MainMasilaAnswer_is.split(","));
                m.addAttribute("UnAvailSeats", bookedSeatList);
            }
        }

        m.addAttribute("date", date);
        m.addAttribute("time", time);
        m.addAttribute("movieName", movieName);
        return "seatselection";
    }

    @GetMapping("/Masila")
    @Transactional
    public String Selected_Seats(@RequestParam(name = "seat", required = false) String selectedSeats, Model model) {
        System.out.println("Selected seats: " + selectedSeats);

        int rupee = 150;

        BDTLS.setSeatts(selectedSeats);
        BDTLS.setDate(date);
        BDTLS.setEmail(bookingUserEmail);
        BDTLS.setName(bookingUserName);
        BDTLS.setMovie_Name(movieName);
        BDTLS.setTime(time);
        BDTLS.setMobile(mobileNumber);
        BDTLS.setRupees(len(selectedSeats) * rupee);

        seatBookingService.save(BDTLS);

        BDTLS = new seat_booking_detailes();

        model.addAttribute("movieName", movieName);
        model.addAttribute("seats", selectedSeats);
        model.addAttribute("time", time);
        model.addAttribute("price", len(selectedSeats) * rupee);

        return "BookingSuccess";
    }

    private int len(String selectedSeats) {
        if (selectedSeats != null && !selectedSeats.isEmpty()) {
            return selectedSeats.split(",").length;
        }
        return 0;
    }

    @GetMapping("/home")
    public String home1() {
        return "home";
    }
    
}
