package com.example.Controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.model.users;
import com.example.repo.UserInterFace;

@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserInterFace service;

    // Create user
    @PostMapping("/RegisterUser")
    public void registerUser(@RequestBody users user) {
        service.save(user);
        System.out.println("User saved: " + user);
    }

    // Select all users
    @GetMapping("/allUsers")
    public List<users> selectUsers() {
        return service.findAll();
    }

    // Delete user by ID
    @DeleteMapping("/DeleteUsers/{id}")
    public void deleteUser(@PathVariable int id) {
        users user = service.findById(id).orElse(null);
        if (user != null) {
            service.delete(user);
        }
    }

    // Update user by ID (example with static data)
    @PutMapping("/UpdateUser/{id}")
    public users updateUser(@PathVariable int id) {
        users user = service.findById(id).orElse(null);
        if (user != null) {
            user.setName("rajini");
            user.setEmail("rajini@gmail.com");
            user.setPassword("000");
            service.save(user);
            return user;
        }
        return null;
    }

    // Find user by ID
    @GetMapping("/FindById/{id}")
    public users findByUserID(@PathVariable int id) {
        return service.findById(id).orElse(null);
    }
}
