package com.example.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.seat_booking_detailes;
import com.example.repo.seatBookingRepo;

@RestController
public class SeatBookingController {

    @Autowired
    private seat_booking_detailes deatiles;

    @Autowired
    private seatBookingRepo service;
	/*
	 * @GetMapping("/BookingDTLS") public void save() { deatiles.setName("Masila");
	 * deatiles.setDate("22-02-2001"); deatiles.setEmail("Masila@gmail.com");
	 * deatiles.setId(4); deatiles.setRupees(50000); deatiles.setTime("10:30");
	 * service.save(deatiles); }
	 */
    @GetMapping("/ManualBookingDTLS")
    public void save() {
        //...
    }

}
